public interface Soldat {
    String obtenirDescription();
    int obtenirForce();
    int obtenirDefense();
}